# -*- mode: python ; coding: utf-8 -*-


a = Analysis(
    ['snaprename.py'],
    pathex=[],
    binaries=[],
    datas=[('main.py', '.'), ('tui.py', '.'), ('engine.py', '.'), ('utils.py', '.'), ('logo.png', '.'), ('undo_log.json', '.')],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Snap Rename',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=['logo.icns'],
)
coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name='Snap Rename',
)
app = BUNDLE(
    coll,
    name='Snap Rename.app',
    icon='logo.icns',
    bundle_identifier='in.satvik-web.snaprename',
)
